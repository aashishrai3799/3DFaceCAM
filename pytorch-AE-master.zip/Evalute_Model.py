import torch
import torch.utils.data
from torch import nn, optim
from torch.nn import functional as F
from torchvision import datasets, transforms
import numpy as np
import Data_PCA
import sys
from mesh_obj import mesh_obj
sys.path.append('../')

from architectures import FC_Encoder, FC_Decoder, CNN_Encoder, CNN_Decoder,Encoder_arch,Decoder_arch
from datasets import MNIST, EMNIST, FashionMNIST,CostumDataset
def Evaluet_the_model_after_reduction():
    device = torch.device('cuda:7')
    Data = np.load('Reduced_Data_Displacement.npy')
    Template_mesh = '/home/godel/Documents/Datasets/Facescape/facescape_trainset/facescape_trainset_001_100/2/models_reg/1_neutral.obj'
    obj_mesh_template = mesh_obj(Template_mesh)
    verts = np.array(obj_mesh_template.vertices)
    m = verts.shape[0];
    n = verts.shape[1]
    verts = np.reshape(verts, m * n)
    trainset = torch.Tensor(Data)
    # trainset.to(device)
    PATH_D = 'Decoder_Checkpoint/1750'
    Decoder = Decoder_arch()
    Decoder.to(device)
    Decoder.load_state_dict(torch.load(PATH_D, map_location=device))
    # print('===============================================')
    # test_noise = torch.randn(100, 128)
    # img = generator(test_noise)
    # rand = img.detach().numpy()
    Data_ = []
    for i in range(len(Data)):
        rand_ = trainset[i, 0:200]
        id_gr = trainset[i, 200]
        ex_gr = trainset[i, 201]
        print(Data[i,:])



        z = rand_.to(device)

        # R = list(z.cpu().data.numpy())
        # GL = id_gr.item()
        # R.append(GL)
        # GL_e = ex_gr.item()
        # R.append(GL_e)
        # R = np.asarray(R)
        # Data_.append(R)
        # print('==========================================')
        # X_orig = rand_.detach().numpy()+verts
        # X = np.asarray(X_orig.reshape(26317, 3))
        # Data_PCA.vertix_to_mesh_origin(X,1, i)
        z.to(device)
        rec_=Decoder(z)
        X_rec = rec_.cpu().data.numpy()+verts
        X = np.asarray(X_rec.reshape(26317, 3))
        Data_PCA.vertix_to_mesh(X, 1, i)
        print('stop+start')
        # print('==================================================')

def Evaluet_the_model():
    device=torch.device('cuda:7')
    Data = np.load('Displace_Label.npy')
    Template_mesh = '/home/godel/Documents/Datasets/Facescape/facescape_trainset/facescape_trainset_001_100/2/models_reg/1_neutral.obj'
    obj_mesh_template = mesh_obj(Template_mesh)
    verts = np.array(obj_mesh_template.vertices)
    m = verts.shape[0];
    n = verts.shape[1]
    verts = np.reshape(verts, m * n)
    trainset = torch.Tensor(Data)
    trainset.to(device)
    PATH_E='Encoder_Checkpoint/1750'
    Encoder_= Encoder_arch()
    Encoder_.to(device)
    # print(Encoder.state_dict())

    Encoder_.load_state_dict(torch.load(PATH_E,map_location=device))
    # print('===============================================')
    # # print(Encoder.state_dict())
    PATH_D = 'Decoder_Checkpoint/1750'
    Decoder = Decoder_arch()
    Decoder.to(device)
    Decoder.load_state_dict(torch.load(PATH_D,map_location=device))
    # print('===============================================')
    # test_noise = torch.randn(100, 128)
    #img = generator(test_noise)
    # rand = img.detach().numpy()
    Data_ = []
    for i in range(len(Data)):
        rand_=trainset[i,0:78951]
        id_gr=trainset[i,78951]
        ex_gr = trainset[i, 78952]
        # print(Data[i,:])

        id_feature,id_label,ex_feature,ex_label=Encoder_(rand_.to(device))

        z = torch.cat((id_feature, ex_feature), 0)

        R=list(z.cpu().data.numpy())
        GL=id_gr.item()
        R.append(GL)
        GL_e = ex_gr.item()
        R.append(GL_e)
        R=np.asarray(R)
        Data_.append(R)
        #print('==========================================')
        # X_orig = rand_.detach().numpy()+verts
        # X = np.asarray(X_orig.reshape(26317, 3))
        # Data_PCA.vertix_to_mesh_origin(X,1, i)
        # z.to(device)
        # rec_=Decoder(z)
        # X_rec = rec_.cpu().data.numpy()+verts
        # X = np.asarray(X_rec.reshape(26317, 3))
        # Data_PCA.vertix_to_mesh(X, 1, i)
        # print('stop+start')
        # print('==================================================')
    Data_=np.asarray(Data_)
    np.save('Reduced_Data_Displacement.npy', Data_)
#Evaluet_the_model()
Evaluet_the_model_after_reduction()