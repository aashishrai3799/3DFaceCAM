from mesh_obj import mesh_obj
import numpy as np
import os
import glob
from sklearn.decomposition import PCA
from mpl_toolkits import mplot3d
import numpy as np
import matplotlib.pyplot as plt
import pickle as pk

Data=np.load('Data_Label.npy')
Template_mesh='/home/godel/Documents/Datasets/Facescape/facescape_trainset/facescape_trainset_001_100/2/models_reg/1_neutral.obj'
obj_mesh_template = mesh_obj(Template_mesh)
verts = np.array(obj_mesh_template.vertices)
m = verts.shape[0];n = verts.shape[1]
verts=np.reshape(verts,m*n)
for i in range(len(Data)):
    # print(Data[i, :])
    Data[i,0:78951]=Data[i,0:78951]-verts
    # print(verts)
    # print(Data[i,:])
    # print('hellp')
print(Data.shape)
np.save('Displace_Label.npy', Data)
