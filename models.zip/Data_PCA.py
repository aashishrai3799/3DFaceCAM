from mesh_obj import mesh_obj
import numpy as np
import os
import glob
from sklearn.decomposition import PCA
from mpl_toolkits import mplot3d
import numpy as np
import matplotlib.pyplot as plt
import pickle as pk

def InversePCA():
    X_orig = np.load('FaceScape_PCA_30.npy')
    pca_reload = pk.load(open("PCA_FaceScape_30.pkl", 'rb'))
    for i in range (100):
         rand_=X_orig[i,:]
         X_re_orig = pca_reload.inverse_transform(rand_)
         X=np.asarray(X_re_orig.reshape(26317,3))
         vertix_to_mesh(X, i)
def PCA_FaceScape():
    # pca = PCA(30)
    X_orig = np.load('Data.npy')
    print( X_orig.shape)
    # pca.fit(X_orig)
    pca_reload = pk.load(open("PCA_FaceScape_30.pkl", 'rb'))
    FaceScape_PCA_30=pca_reload.transform(X_orig)
    print(FaceScape_PCA_30.shape)
    np.save('FaceScape_PCA_30.npy', FaceScape_PCA_30)

    # varians=pca_reload.explained_variance_
    # varians=np.sqrt(varians)
    # for i in range (100):
    #      rand_=np.random.uniform(low=-2.5, high=2.5, size=30)
    #      sample=np.multiply(rand_,varians)
    #      X_re_orig = pca_reload.inverse_transform(sample)
    #      X=np.asarray(X_re_orig.reshape(26317,3))
    #      vertix_to_mesh(X, i)
    #X_re_orig = pca.inverse_transform(pca.transform(sample))

    print('Finish')

def PCA_Dimension():
    pca = PCA()
    X_orig = np.load('Data.npy')
    pca.fit(X_orig)
    # pca.fit_transform(X_orig)
    #X_re_orig = pca.inverse_transform(pca.transform(sample))
    A=pca.explained_variance_
    B = pca.components_
    pk.dump(pca, open("PCA_FaceScape.pkl", "wb"))
    np.save('pca_Eigenvalue.npy',A)
    np.save('pca_Eigenvector.npy',B)
    cumsum = np.cumsum(pca.explained_variance_ratio_)
    np.save('Energy.npy', cumsum)
    d = np.argmax(cumsum >= 0.95) + 1
    np.save('Dimesion.npy', d)
    # print(d)
    # print(cumsum)
    # plt.plot(cumsum)
    # plt.xlabel('number of components')
    # plt.ylabel('cumulative explained variance')
    # plt.show()
def All_Data():
    address= os.listdir('Vertex_file')
    count=0
    Data_=[]
    for file_ in address:
        count+=1
        num_file = open('Vertex_file/'+file_, "r")
        content_list = num_file.readlines()
        Data_.append(list(np.float_(content_list )))
        print(count)
    Data_= np.asarray(Data_)
    np.save('Data.npy', Data_)
def PCA_Op():
    # pca = PCA(5)
    # X_orig = [[1,2,3,4,5],[6,7,8,9,10],[11,12,13,14,15],[12,22,32,42,25],[13,23,33,43,35]]
    # sample=np.random.rand(1, 5)
    # pca.fit(X_orig)
    # A=pca.explained_variance_
    # B = pca.components_
    # pk.dump(pca, open("pca.pkl", "wb"))
    # print(A)
    pca_reload = pk.load(open("pca.pkl", 'rb'))
    A=np.load('pca_c.npy')
    B=np.load('pca_v.npy')
    print(A)
    print(B)
    print('-------------------------------------')
    print(pca_reload.components_)
    print(pca_reload.explained_variance_)
    #print(pca.components_)
    #print( np.save('pca.npy',A)

    # pca.fit_transform(X_orig)
    # X_re_orig = pca.inverse_transform(pca.transform(sample))
    # print(sample)
    # print(X_re_orig)
    #cumsum = np.cumsum(pca.explained_variance_ratio_)

    #d = np.argmax(cumsum >= 0.95) + 1

    # plt.plot(cumsum)
    # plt.xlabel('number of components')
    # plt.ylabel('cumulative explained variance')
    # plt.show()

    # plt.scatter(X_orig[:, 0], X_orig[:, 1], label='Original points')
    # plt.scatter(X_re_orig[:, 0], X_re_orig[:, 1], label='InverseTransform',s=7)
    # [plt.plot([X_orig[i, 0], X_re_orig[i, 0]], [X_orig[i, 1], X_re_orig[i, 1]]) for i in range(10)]
    # plt.legend()
    # plt.show()

def vertix_to_mesh(verts, name, count):
    path = 'Generated_mesh/' + str(name)+'/'
    isExist = os.path.exists(path)
    if not isExist:
        os.makedirs(path)
    Template_mesh='/home/godel/Documents/Datasets/Facescape/facescape_trainset/facescape_trainset_001_100/2/models_reg/1_neutral.obj'
    obj_mesh_template = mesh_obj(Template_mesh)
    obj_0 = mesh_obj()
    obj_0.create(vertices=verts)
    obj_0.faces = obj_mesh_template.faces
    obj_0.export('Generated_mesh/'+str(name)+'/'+'obj_mesh_' + str(count) + '.obj')
def vertix_to_mesh_origin(verts, name, count):
    path = 'Generated_mesh/' + str(name)+'/'
    isExist = os.path.exists(path)
    if not isExist:
        os.makedirs(path)
    Template_mesh='/home/godel/Documents/Datasets/Facescape/facescape_trainset/facescape_trainset_001_100/2/models_reg/1_neutral.obj'
    obj_mesh_template = mesh_obj(Template_mesh)
    obj_0 = mesh_obj()
    obj_0.create(vertices=verts)
    obj_0.faces = obj_mesh_template.faces
    obj_0.export('Generated_mesh/' +str(name)+'/'+'obj_mesh_origin'+str(count) + '.obj')
def read_meshes():
    count=0
    # path = "/home/godel/Students_Codes/Fariborz/Vinila/Vertex_file"
    # isExist = os.path.exists(path)
    # if not isExist:
    #     os.makedirs(path)
    mesh_dir="/home/godel/Documents/Datasets/Facescape/facescape_trainset"
    my_list = os.listdir(mesh_dir)
    for item in my_list:
        address=mesh_dir+'/'+item
        for file_ in glob.glob(address+'/*'):
            address_=file_+'/models_reg'
            for mesh_file in glob.glob(address_+'/*.obj'):
                count+=1
                mesh = mesh_obj(mesh_file)
                verts = np.array(mesh.vertices)
                #vertix_to_mesh(verts, count)
                m=verts.shape[0];n= verts.shape[1]
                # print(verts.shape)
                # verts=np.reshape(verts,m*n)
                # print(verts.shape)
                # with open(path+'/'+str(count), "w") as f:
                #     for i in range(m*n):
                #        f.write(str(verts[i])+'\n')
                # f.close()
                # # print(List_)
                # # fig = plt.figure(figsize=(10, 7))
                # # ax = plt.axes(projection="3d")
                # # ax.scatter3D(verts[:,0], verts[:,1], verts[:,2], color="green",s=2)
                # # plt.title("simple 3D scatter plot")
                # # plt.show()
                # #np.savetxt('test.out2',  verts , delimiter=',')
                # print(count)
    # np.savetxt('test.out2',  np.asarray(List_) , delimiter=',')
if __name__ == '__main__':
    #PCA_Op()
    #read_meshes()
    # All_Data()
    #PCA_Dimension()
    #PCA_FaceScape()
    InversePCA()
