import torch
from torchvision import datasets, transforms
import  numpy as np
class MNIST(object):
    def __init__(self, args):
        kwargs = {'num_workers': 1, 'pin_memory': True} if args.cuda else {}
        self.train_loader = torch.utils.data.DataLoader(
            datasets.MNIST('data/mnist', train=True, download=True,
                           transform=transforms.ToTensor()),
            batch_size=args.batch_size, shuffle=True, **kwargs)
        self.test_loader = torch.utils.data.DataLoader(
            datasets.MNIST('data/mnist', train=False, transform=transforms.ToTensor()),
            batch_size=args.batch_size, shuffle=True, **kwargs)

class EMNIST(object):
    def __init__(self, args):
        kwargs = {'num_workers': 1, 'pin_memory': True} if args.cuda else {}
        self.train_loader = torch.utils.data.DataLoader(
            datasets.EMNIST('data/emnist', train=True, download=True, split='byclass',
                           transform=transforms.ToTensor()),
            batch_size=args.batch_size, shuffle=True, **kwargs)
        self.test_loader = torch.utils.data.DataLoader(
            datasets.EMNIST('data/emnist', train=False, split='byclass',
            transform=transforms.ToTensor()),
            batch_size=args.batch_size, shuffle=True, **kwargs)

class FashionMNIST(object):
    def __init__(self, args):
        kwargs = {'num_workers': 1, 'pin_memory': True} if args.cuda else {}
        self.train_loader = torch.utils.data.DataLoader(
            datasets.FashionMNIST('data/fmnist', train=True, download=True,
                           transform=transforms.ToTensor()),
            batch_size=args.batch_size, shuffle=True, **kwargs)
        self.test_loader = torch.utils.data.DataLoader(
            datasets.FashionMNIST('data/fmnist', train=False, transform=transforms.ToTensor()),
            batch_size=args.batch_size, shuffle=True, **kwargs)
class CostumDataset(object):
    def __init__(self, args):
        kwargs = {'num_workers': 4, 'pin_memory': True} if args.cuda else {}
        Data=np.load('Displace_Label.npy')
        Feature=Data[:,0:78951]
        Label_id=Data[:,78951]
        Label_ex = Data[:, 78952]
        tensor_x = torch.Tensor(Feature)  # transform to torch tensor
        tensor_y = torch.Tensor(Label_id)
        tensor_z = torch.Tensor(Label_ex)

        trainset = torch.utils.data.TensorDataset(tensor_x, tensor_y,tensor_z)  # create your datset

        #trainset = torch.Tensor(Data)
        self.train_loader = torch.utils.data.DataLoader(trainset,  batch_size=args.batch_size, shuffle=True,**kwargs)
        self.test_loader = torch.utils.data.DataLoader(trainset, batch_size=args.batch_size, shuffle=True, **kwargs)
        # self.train_loader = torch.utils.data.DataLoader(
        #     datasets.CostumDataset('Data.npy', train=True, download=True,
        #                    transform=transforms.ToTensor()),
        #     batch_size=args.batch_size, shuffle=True, **kwargs)
        # self.test_loader = torch.utils.data.DataLoader(
        #     datasets.FashionMNIST('Data.npy', train=False, transform=transforms.ToTensor()),
        #     batch_size=args.batch_size, shuffle=True, **kwargs)