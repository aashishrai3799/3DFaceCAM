import os


in_path = 'interpol_id/'
out_path = 'interpol_id/'


def check_folder(path):
	if not os.path.exists(path):
		os.mkdir(path)

check_folder(out_path)

base_obj = open('base_obj.obj', "r")
base_lines = base_obj.readlines()

base_mtl = open('base_mtl.mtl', "r")
base_mtl_lines = base_mtl.readlines()

folders = os.listdir(in_path)
folders.sort()

for folder in folders:
	
	check_folder(os.path.join(out_path, folder))
	exps = os.listdir(os.path.join(in_path,folder))
	exps.sort()
	
	#for exp in exps:
	for exp in ['17_eye_closed', '1_smile', '0_neutral', '2_mouth_stretch']:
		
		check_folder(os.path.join(out_path, folder, exp))
		files = os.listdir(os.path.join(in_path, folder, exp))
		files.sort()
		
		obj_out_path = os.path.join(out_path, folder, exp)
		obj_in_path = os.path.join(in_path, folder, exp)

		for f in files:
			
			if 'obj' in f:
				
				obj_filename = os.path.join(obj_in_path, f)

				a_file = open(obj_filename, "r")
				lines = a_file.readlines()
				#print(lines[56864])

				base_lines[1:26318] = lines[:26317]
				base_lines[0] = 'mtllib ./' + f[:-4] + '.mtl\n'
				#print(lines[56864])

				with open(os.path.join(obj_out_path, f), 'w') as new_obj:
					new_obj.writelines(base_lines)
					new_obj.close()
				
				print(f)	
				with open(os.path.join(obj_out_path, f[:-4] + '.mtl'), 'w') as new_mtl:
					base_mtl_lines[7] = 'map_Kd ' + str(f[:-4]) + '.jpg'
					new_mtl.writelines(base_mtl_lines)
					new_mtl.close()


