# Created by Chen Henry Wu
import os
import math
import numpy as np
import matplotlib.pyplot as plt

from PIL import Image

from utils.file_utils import save_images
import torch
import torchvision
import torch.nn.functional as F
from model.lib.gan3d.mesh_obj import mesh_obj
from model.lib.gan3d.renderer import render_cvcam

from pytorch3d.structures import Meshes
from pytorch3d.renderer import (
    FoVPerspectiveCameras, look_at_view_transform,
    RasterizationSettings, BlendParams,
    MeshRenderer, MeshRasterizer, HardPhongShader,
    HardGouraudShader, SoftGouraudShader,TexturesVertex,
    TexturesUV,DirectionalLights
)


class Visualizer(object):

    def __init__(self, args):
        self.args = args
        # TODO: does not support multi-task

    def visualize(self,
                  images,
                  model,
                  description: str,
                  save_dir: str,
                  step: int,
                  ):
        if images is None:
            return

        # Just visualize the first 64 images.
        images = images[:25].float()
        images = torch.reshape(images, (images.shape[0],26317, 3))
        face_v = torch.from_numpy(np.load('/data/shaunak/StyleGAN2/model/lib/gan3d/face_v.npy')).to(dtype=torch.float32)
        face_v = face_v.unsqueeze(0)-1
        print(face_v.shape)
        face_vt = torch.from_numpy(np.load('/data/shaunak/StyleGAN2/model/lib/gan3d/face_vt.npy')).to(dtype=torch.float32)
        face_vt = face_vt.unsqueeze(0)-1
        print(face_vt.shape)
        ref_mesh = mesh_obj('/data/shaunak/StyleGAN2/model/lib/gan3d/template_mesh.obj')
        ref_verts = torch.from_numpy(np.array(ref_mesh.vertices)).float()
        device = "cuda:2"

        tex_mesh = mesh_obj("/home/godel/Documents/Datasets/Facescape/facescape_trainset/facescape_trainset_001_100/2/models_reg/1_neutral.obj")
        texmap = torch.from_numpy(np.array(tex_mesh.texcoords)).unsqueeze(dim=0)
        texmap = torch.cat([texmap]*images.shape[0])
        print(texmap.shape)


        # verts_rgb = torch.ones_like(images)[None] + 0.1*torch.rand_like(images)[None]# (1, V, 3)
        # verts_rgb[:,:,:,0] = verts_rgb[:,:,:,0]*255/255
        # verts_rgb[:,:,:,1] = verts_rgb[:,:,:,1]*224/255
        # verts_rgb[:,:,:,2] = verts_rgb[:,:,:,2]*189/255
        # verts_rgb[:,:,6571,:2] = 0
        # verts_rgb[:,:,5231,:2] = 0
        # textures = TexturesVertex(verts_features=verts_rgb.squeeze().to(device))

        ##Load UV texture
        # tex = torch.from_numpy(np.array([plt.imread('/data/aashish/texture_samples/16057.jpg')/255]*2))
        # tex_filename = '/data/aashish/texture_samples/16057.jpg'
        tex_filenames = os.listdir('/data/aashish/codes/data_loader/texture_results/1_neutral/')
        imgs = []
        for file in tex_filenames:
            tex_filename = tex_paths = os.path.join('/data/aashish/codes/data_loader/texture_results/1_neutral/',file)
            with Image.open(tex_filename) as image:
                np_image = np.asarray(image.convert("RGB")).astype(np.float32)
                tex = torch.from_numpy(np_image / 255.)[None]
            imgs.append(tex)
        # tex = torch.cat(images.shape[0]*[tex])
        tex = torch.stack(imgs).squeeze(dim=1)
        # tex = torch.cat((tex,tex[:5]))
        print(tex.shape)
        print(tex.shape)
        textures = TexturesUV(maps=tex, faces_uvs=torch.cat(images.shape[0]*[face_vt]).long(), verts_uvs=texmap.float(), align_corners=True)

        meshes = Meshes(verts=images+ref_verts, faces=torch.cat(images.shape[0]*[face_v]), textures=textures).to(device)
        R, T = look_at_view_transform(250, 0, 0)
        cameras = FoVPerspectiveCameras(device=device, R=R, T=T)

        raster_settings = RasterizationSettings(
            image_size=512,
            blur_radius=0.0,
            faces_per_pixel=1,
            cull_backfaces=True,
            )

        blend_params=BlendParams()
        blend_params._replace(background_color=(0.0,0.0,0.0))

        renderer = MeshRenderer(
            rasterizer=MeshRasterizer(cameras=cameras, raster_settings=raster_settings),
            shader=HardPhongShader(device=device, cameras=cameras, blend_params=blend_params)
            )

        images = renderer(meshes,cameras=cameras,lights=DirectionalLights(device=device, direction=((0,0,1),)))

        images = images.permute(0,3,1,2)
        torchvision.utils.save_image(images,fp='sa.png',nrow=5)
        save_images(
            images,
            output_dir=save_dir,
            file_prefix=description,
            nrows=int(math.sqrt(len(images))),
            iteration=step,
        )

        # Lower resolution
        images_256 = F.interpolate(
            images,
            (256, 256),
            mode='bicubic',
        )
        save_images(
            images_256,
            output_dir=save_dir,
            file_prefix=f'{description}_256',
            nrows=int(math.sqrt(len(images))),
            iteration=step,
        )
