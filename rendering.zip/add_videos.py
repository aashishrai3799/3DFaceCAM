import os
import numpy as np
import cv2

#exps = ['1_smile.avi', '2_mouth_stretch.avi', '3_anger.avi', '4_jaw_left.avi', '5_jaw_right.avi', '6_jaw_forward.avi', '7_mouth_left.avi', '8_mouth_right.avi', '9_dimpler.avi', '10_chin_raiser.avi', '11_lip_puckerer.avi', '12_lip_funneler.avi', '13_sadness.avi', '14_lip_roll.avi', '16_cheek_blowing.avi', '17_eye_closed.avi', '18_brow_raiser.avi', '19_brow_lower.avi']


def add_videos_idd():

	in_path = 'videos_interpolation/'
	out_path = in_path
	
	exps = ['0_neutral.avi', '1_smile.avi', '2_mouth_stretch.avi', '17_eye_closed.avi']

	idds = os.listdir(in_path)
	idds.sort()

	full_frame = np.zeros((15*4, 512*2, 512*2, 3), dtype='uint8')
	fourcc = cv2.VideoWriter_fourcc(*'mp4v')

	for idd in idds:

		video = cv2.VideoWriter(os.path.join(out_path, idd, 'combined.avi'), fourcc, 10, (512*2,512*2))
		
		r=0
		c=0

		for i in range(4):

			count=0

			cap = cv2.VideoCapture(os.path.join(in_path, idd, exps[i]))
			
			while(cap.isOpened()):
				#print(i,r,c)
				ret, frame = cap.read()
				if ret == True:
					#print(count)
					frame = cv2.resize(frame, (512,512))
					full_frame[count,512*r:512*(r+1),512*c:512*(c+1),:] = frame
					
					count+=1

					#video.write(image_full)
					
				else:
					break

			c+=1
			if c%2==0:
				c=0
				r+=1
			
		for i in range(56):
			full_frame2 = cv2.resize(full_frame[i], (512*2,512*2))
			video.write(full_frame2)
			#cv2.imshow('frame', full_frame2)
			#cv2.waitKey(100)

		video.release()	
		cap.release()
		cv2.destroyAllWindows()
		
		
def add_videos_exp():

	exps = ['sample_0.avi', 'sample_1.avi', 'sample_11.avi', 'sample_12.avi', 'sample_13.avi', 'sample_14.avi', 'sample_16.avi', 'sample_18.avi', 'sample_3.avi', 'sample_4.avi', 'sample_5.avi', 'sample_15.avi']
	
	in_path = 'exp_videos/'
	out_path = in_path

	idds = os.listdir(in_path)
	idds.sort()

	full_frame = np.zeros((15*4, 512*2, 512*6, 3), dtype='uint8')
	fourcc = cv2.VideoWriter_fourcc(*'mp4v')

	for idd in idds[:]:
	
		idd = '17_eye_closed'

		video = cv2.VideoWriter(os.path.join(out_path, idd, 'combined.avi'), fourcc, 10, (512*5,512*2))
		
		r=0
		c=0

		for i in range(12):

			count=0

			cap = cv2.VideoCapture(os.path.join(in_path, idd, exps[i]))
			
			while(cap.isOpened()):
				#print(i,r,c)
				ret, frame = cap.read()
				if ret == True:
					#print(count)
					full_frame[count,512*r:512*(r+1),512*c:512*(c+1),:] = frame
					
					count+=1

					#video.write(image_full)
					
				else:
					break

			c+=1
			if c%6==0:
				c=0
				r+=1
			
		for i in range(56):
			full_frame2 = cv2.resize(full_frame[i], (512*5,512*2))
			video.write(full_frame2)
			#cv2.imshow('frame', full_frame2)
			#cv2.waitKey(100)

		video.release()	
		cap.release()
		cv2.destroyAllWindows()
		

def add_videos_random():

	exps = ['sample_10.avi', 'sample_11.avi', 'sample_12.avi', 'sample_13.avi', 'sample_14.avi', 'sample_15.avi', 'sample_16.avi', 'sample_17.avi', 'sample_18.avi', 'sample_19.avi', 'sample_2.avi', 'sample_3.avi', 'sample_4.avi', 'sample_5.avi', 'sample_6.avi', 'sample_7.avi', 'sample_8.avi', 'sample_9.avi']
	
	#exps = ['sample_1.avi', 'sample_1.avi', 'sample_10.avi', 'sample_11.avi']
	
	in_path = 'video_interp_exps/'
	out_path = in_path

	idds = os.listdir(in_path)
	idds.sort()

	full_frame = np.zeros((15*4, 512*3, 512*6, 3), dtype='uint8')
	fourcc = cv2.VideoWriter_fourcc(*'mp4v')

	for idd in idds[:]:
	
		#idd = '17_eye_closed'

		video = cv2.VideoWriter(os.path.join(out_path, idd, 'combined_all.avi'), fourcc, 10, (512*4,512*2))
		
		r=0
		c=0

		for i in range(18):

			count=0

			cap = cv2.VideoCapture(os.path.join(in_path, idd, exps[i]))
			
			while(cap.isOpened()):
				#print(i,r,c)
				ret, frame = cap.read()
				if ret == True:
					#print(count)
					frame = cv2.resize(frame, (512,512))
					full_frame[count,512*r:512*(r+1),512*c:512*(c+1),:] = frame
					
					count+=1

					#video.write(image_full)
					
				else:
					break

			c+=1
			if c%6==0:
				c=0
				r+=1
			
		for i in range(56):
			full_frame2 = cv2.resize(full_frame[i], (512*4,512*2))
			video.write(full_frame2)
			#cv2.imshow('frame', full_frame2)
			#cv2.waitKey(100)

		video.release()	
		cap.release()
		cv2.destroyAllWindows()		
		
		
add_videos_idd()







