import os
import cv2
import glob

exps = ['1_smile.avi', '2_mouth_stretch.avi', '3_anger.avi', '4_jaw_left.avi', '5_jaw_right.avi', '6_jaw_forward.avi', '7_mouth_left.avi', '8_mouth_right.avi', '9_dimpler.avi', '10_chin_raiser.avi', '11_lip_puckerer.avi', '12_lip_funneler.avi', '13_sadness.avi', '14_lip_roll.avi', '16_cheek_blowing.avi', '17_eye_closed.avi', '18_brow_raiser.avi', '19_brow_lower.avi']


def one_expression_video(in_path, out_path):

	resln = 1024
	fourcc = cv2.VideoWriter_fourcc(*'mp4v')
	video = cv2.VideoWriter(out_path, fourcc, 10, (resln, resln))

	files=[]

	for i in range(2):

		for i in range(1,15):
			
			image_full=cv2.imread(os.path.join(in_path, str(i)+'.jpg'))
			image_full = cv2.resize(image_full, (resln,resln))
			#cv2.imshow('frame', image_full)
			#cv2.waitKey(100)
			video.write(image_full)
		
		#cv2.waitKey(5000)
		
		for i in range(1,15):
			
			image_full=cv2.imread(os.path.join(in_path, str(15-i)+'.jpg'))
			image_full = cv2.resize(image_full, (resln,resln))
			#cv2.imshow('frame', image_full)
			#cv2.waitKey(100)
			video.write(image_full)
		
		#cv2.waitKey(1000)
		
	#print(files)

	cv2.destroyAllWindows()
	video.release()
	
def check_folder(path):
	if not os.path.exists(path):
		os.mkdir(path)

in_path = 'rendered_id_interpolation/'
out_path = 'videos_interpolation/'

check_folder(out_path)


idds = os.listdir(in_path)
idds.sort()

for idd in idds:
#for idd in ['sample_14','sample_19']: #idds[:1]:

	exps = os.listdir(os.path.join(in_path, idd))
	exps.sort()
	
	check_folder(os.path.join(out_path, idd))
	
	for exp in exps:	
	
		one_expression_video(os.path.join(in_path,idd,exp), os.path.join(out_path, idd, exp+'.avi'))	
		print(idd, end='\r')

	
	
	
	
	
	
	
